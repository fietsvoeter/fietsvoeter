'use client'
import React from 'react'
import Link from 'next/link'
import { TableOfContents } from '@/components/TableOfContents'
import { BandendruKCalculator } from '@/components/BandendruKCalculator'

const PARTNER_ID = '1361557'
const YEAR = new Date().getFullYear()

function bolLink(search: string, partnerId = PARTNER_ID): string {
  const productUrl = `https://www.bol.com/nl/nl/s/?searchtext=${encodeURIComponent(search)}`
  return `https://partner.bol.com/click/click?p=2&t=url&s=${partnerId}&f=TXL&url=${encodeURIComponent(productUrl)}`
}

export function BolBtn({
  search, label, url, partner = PARTNER_ID,
}: {
  search: string; label: string; url?: string; partner?: string
}) {
  const baseHref = url && url.startsWith('https://partner.bol.com') ? url : bolLink(search, partner)
  const [href, setHref] = React.useState(baseHref)

  React.useEffect(() => {
    const slug = window.location.pathname.replace(/\/$/, '').split('/').pop() || ''
    const su1 = encodeURIComponent(slug.slice(0, 50))
    const su2 = encodeURIComponent(search.slice(0, 50))
    setHref(baseHref + '&su1=' + su1 + '&su2=' + su2)
  }, [baseHref, search])

  return (
    <a href={href} target="_blank" rel="noopener sponsored nofollow" className="bol-btn">
      <span className="bol-dot">●</span>{label} op bol.com
    </a>
  )
}

export function Disclaimer() {
  return (
    <div className="disclaimer">
      <strong>✓ Transparantie:</strong> Wij testen producten onafhankelijk in {YEAR}.
      Via bol.com-links ontvangen wij commissie — zonder extra kosten voor jou.{' '}
      <Link href="/affiliate-disclosure/" className="text-brand-red">Meer info</Link>.
    </div>
  )
}

export function UpdateBadge({ date, changes }: { date: string; changes: string }) {
  return <div className="update-badge"><strong>🔄 Bijgewerkt {date}:</strong> {changes}</div>
}

export function GeoBlock({ region, text }: { region: string; text: string }) {
  return <div className="geo-block"><strong>📍 In {region}?</strong> {text}</div>
}

export function ExpertQuote({ quote, name, role }: { quote: string; name: string; role: string }) {
  const parseLink = (n: string) => {
    const m = n.match(/^\[(.+?)\]\((.+?)\)$/)
    if (m) return <a href={m[2]} className="hover:text-red-600 transition-colors font-semibold">{m[1]}</a>
    return <strong>{n}</strong>
  }
  return (
    <blockquote className="expert-quote">
      <p>"{quote}"</p>
      <footer>{parseLink(name)} — {role}</footer>
    </blockquote>
  )
}

export function FAQ({ items }: { items?: { question: string; answer: string }[] }) {
  if (!items || !Array.isArray(items)) return null
  return (
    <div className="my-8">
      <h2>Veelgestelde vragen</h2>
      {items.map((item, i) => (
        <div key={i} className="mb-4">
          <h3 className="mt-5 mb-2">{item.question}</h3>
          <p className="text-gray-600 leading-relaxed">{item.answer}</p>
        </div>
      ))}
    </div>
  )
}

export function Score({ score, label, value }: {
  score?: number | string
  label?: string
  value?: number | string
}) {
  const raw = score ?? value ?? 0
  const num = typeof raw === 'string' ? parseFloat(raw) : (raw as number)
  const safe = isNaN(num) ? 0 : num
  const pct = Math.round((safe / 10) * 100)
  const color =
    safe >= 9.0 ? '#16a34a' :
    safe >= 8.0 ? '#2563eb' :
    safe >= 7.0 ? '#d97706' : '#dc2626'
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px', margin: '12px 0', background: '#f8fafc', border: '1px solid #e2e8f0', borderLeft: `4px solid ${color}`, borderRadius: '6px' }}>
      <div style={{ flexShrink: 0, width: '52px', height: '52px', borderRadius: '50%', background: color, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
        <span style={{ fontSize: '15px', fontWeight: 700, lineHeight: 1 }}>{safe.toFixed(1)}</span>
        <span style={{ fontSize: '9px', opacity: 0.85, lineHeight: 1 }}>/10</span>
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        {label && <div style={{ fontSize: '14px', fontWeight: 600, color: '#1e293b', marginBottom: '6px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</div>}
        <div style={{ height: '6px', background: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: '3px' }} />
        </div>
      </div>
    </div>
  )
}

export function CompareTable({ headers, rows, scoreCol }: {
  headers?: string[]; rows?: (string | number)[][]; scoreCol?: number
}) {
  if (!Array.isArray(headers) || !Array.isArray(rows)) return null
  return (
    <div className="compare-table-wrap">
      <table className="compare-table">
        <thead><tr>{headers.map((h, i) => <th key={i}>{h}</th>)}</tr></thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {Array.isArray(row) && row.map((cell, j) => (
                <td key={j} className={j === scoreCol ? 'font-bold' : ''}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export function RelatedLinks({ pairs }: { pairs?: { slug: string; label: string }[] }) {
  if (!Array.isArray(pairs)) return null
  return (
    <div className="bg-gray-50 rounded p-4 text-sm my-7">
      <strong>Lees ook:</strong>{' '}
      {pairs.map(({ slug, label }, i) => (
        <span key={slug}>{i > 0 && ' · '}
          <Link href={`/blog/${slug}/`} className="text-brand-red font-medium no-underline hover:underline">{label}</Link>
        </span>
      ))}
    </div>
  )
}

export function PostImage({ src, alt, caption, width = 1200, height = 630 }: {
  src: string; alt: string; caption?: string; width?: number; height?: number
}) {
  if (!src) return null
  return (
    <figure className="my-7">
      <img src={src} alt={alt || ''} width={width} height={height}
        loading="lazy" decoding="async" className="w-full h-auto rounded-md"
        style={{ aspectRatio: `${width}/${height}` }} />
      {caption && <figcaption className="text-xs text-gray-400 mt-2 italic">{caption}</figcaption>}
    </figure>
  )
}

export { BandendruKCalculator, TableOfContents }
